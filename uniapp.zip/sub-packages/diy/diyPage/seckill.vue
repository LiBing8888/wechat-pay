<template>
	<!-- 秒杀列表 -->
	<view :style="[boxStyle]" v-if="spikeList.length > 0" class="seckill-wrapper relative">
		<view :style="[wrapperStyle]">
			<!-- 秒杀头部 -->
			<view class="w-full h-96 px-24 flex-between-center bg-cover" :style="[headerStyle]">
				<view class="flex-y-center" :style="[numberBgColor]">
					<text class="fs-32 lh-44rpx fw-500" :style="[titleStyle]" v-if="titleConfig">{{ titleTxtConfig }}</text>
					<image :src="titleImg" class="w-140 h-32" v-else></image>
					<text class="fs-26 text--w111-999 lh-36rpx pl-20" :style="[tipsColor]">距离结束</text>
					<view>
						<countDown :is-day="false" tip-text=" " day-text=" " hour-text=":" minute-text=":" second-text=" "
						:datatime="datatime" :colors="numberColor" :dotColor="dotColor"></countDown>
					</view>
				</view>
				<view class="flex-y-center fs-24 text--w111-999" :style="[headerBntColor]"
					@tap="goPage">
					<text>{{ dataConfig.rightBntConfig.value }}</text>
					<text class="iconfont icon-ic_rightarrow fs-24" :style="[headerBntColor]"></text>
				</view>
			</view>
			<!-- 单列 -->
			<view class="pt-32 pr-20 pb-32 pl-20 bg--w111-fff" :style="[boxContentStyle]" v-if="goodStyleConfig == 0">
				<view class="w-full flex justify-between item" v-for="(item, index) in spikeList" :key="index"
					@tap="goDetails(item)" :style="[goodStyle]">
					<easy-loadimage
					:image-src="item.image"
					width="240rpx"
					height="240rpx"
					:borderRadius="imgStyle"></easy-loadimage>
					<view class="flex-1 flex-col justify-between pl-20 h-240">
						<view>
							<view class="w-full fs-28 h-80 lh-40rpx line2" :style="[productStyle]" v-if="checkboxInfo.includes(0)">
								{{ item.store_name }}</view>
							<view class="w-full flex-y-center mt-20" v-if="checkboxInfo.includes(1)">
								<view class="progress relative">
									<view class="active" :style="{ 'width': item.percent + '%', background: progressBgColor }">
										<!-- <image src="@/static/images/lightning.png" class="lightning"></image> -->
									</view>
									<image :src="`${domain}/static/images/lightning.png`" class="lightning"
										:style="{ left: item.percent + '%', transform: item.percent == 100 ? 'translateX(-100%)' : 'translateX(0)' }">
									</image>
								</view>
								<text class="fs-22 lh-30rpx pl-12" :style="{ color: priceColor }">已抢{{ item.percent + '%' }}</text>
							</view>
						</view>
						<view class="flex justify-between items-end">
							<view class="flex-col">
								<view :style="{ color: priceColor }" v-if="checkboxInfo.includes(2)">
									<text style="font-size: 12px; margin-right: 4px; font-weight: 500">秒杀价</text>
									<priceFormat :price="item.price" intSize="36" floatSize="36" weight></priceFormat>
								</view>
								<text class="text-line fs-28 text--w111-999 pt-10 Regular" v-if="checkboxInfo.includes(3)"
									:style="[otPriceColor]">¥{{ item.ot_price.toString().split('.')[1] ?
										item.ot_price : item.ot_price + '.00' }}</text>
							</view>
							<view class='w-144 h-56 rd-30rpx flex-center fs-24 text--w111-fff' v-if="!showBtn" :style="[btnBgColor, getBtnOtherStyle(item)]">{{ item.skill_status | btnText }}</view>
						</view>
					</view>
				</view>
			</view>
			<!-- 两列 -->
			<view class="grid-column-2 grid-gap-22rpx pt-32 pr-20 pb-32 pl-20" :style="[boxContentStyle]"
				v-if="goodStyleConfig == 1">
				<view v-for="(item, index) in spikeList" :key="index" @tap="goDetails(item)" :style="[goodStyle]">
					<easy-loadimage
					:image-src="item.image"
					width="100%"
					height="324rpx"
					:borderRadius="imgStyle"></easy-loadimage>
					<view class="w-full line2 mt-16 fs-28 lh-40rpx" :style="[productStyle]" v-if="checkboxInfo.includes(0)">
						{{ item.store_name }}</view>
					<view class="flex justify-between items-end mt-10">
						<view class="flex-col">
							<view :style="{ color: priceColor }" v-if="checkboxInfo.includes(2)">
								<priceFormat :price="item.price" intSize="36" floatSize="36" labelSize="24" weight></priceFormat>
							</view>
							<text class="text-line fs-28 text--w111-999 pt-14 Regular" v-if="checkboxInfo.includes(3)"
								:style="[otPriceColor]">¥{{ item.ot_price.toString().split('.')[1] ? item.ot_price
									: item.ot_price + '.00' }}</text>
						</view>
						<view class='w-144 h-56 rd-30rpx flex-center fs-24 text--w111-fff bg--w111-E93323' v-if="!showBtn"
							:style="[btnBgColor, getBtnOtherStyle(item)]">{{ item.skill_status | btnText }}</view>
					</view>
				</view>
			</view>
			<!-- 三列 -->
			<view class="grid-column-3 grid-gap-18rpx pt-32 pr-20 pb-32 pl-20" :style="[boxContentStyle]"
				v-if="goodStyleConfig == 2">
				<view v-for="(item, index) in spikeList" :key="index" @tap="goDetails(item)" :style="[goodStyle]">
					<easy-loadimage
					:image-src="item.image"
					width="100%"
					height="212rpx"
					:borderRadius="imgStyle"></easy-loadimage>
					<view class="w-full line1 mt-12 fs-26" :style="[productStyle]" v-if="checkboxInfo.includes(0)">{{
						item.store_name
					}}
					</view>
					<view class="price-box flex-center relative" :style="[tagBag]" v-if="checkboxInfo.includes(2)">
						<view :style="{ color: bargainPriceColor }">
							<priceFormat :price="item.price" intSize="30" floatSize="30" labelSize="30"></priceFormat>
						</view>
						<image :src="`${domain}/static/images/shandian.png`" class="shandian"></image>
					</view>
					<view class="text-line fs-24 text--w111-999 Regular lh-32rpx mt-10" :style="[otPriceColor]"
						v-if="checkboxInfo.includes(3)">¥{{ item.ot_price.toString().split('.')[1] ?
							item.ot_price : item.ot_price + '.00' }}</view>
				</view>
			</view>
			<!-- 滑动 -->
			<scroll-view scroll-x="true" :show-scrollbar="false" class="white-nowrap vertical-middle w-full pt-32 pl-32 pb-32 border-box"
				:style="[boxContentStyle]" v-if="goodStyleConfig == 3">
				<view style="white-space: nowrap;">
					<view class="inline-block" :class="{ 'ml-20': index }" v-for="(item, index) in spikeList" :key="index"
						@tap="goDetails(item)" :style="[goodStyle]">
						<easy-loadimage
						:image-src="item.image"
						width="224rpx"
						height="224rpx"
						:borderRadius="imgStyle"></easy-loadimage>
						<view class="w-222 line1 mt-16 fs-26 lh-26rpx" :style="[productStyle]" v-if="checkboxInfo.includes(0)">
							{{ item.store_name }}</view>
						<view class="flex justify-between items-end mt-16">
							<view>
								<view :style="{ color: priceColor }" v-if="checkboxInfo.includes(2)">
									<priceFormat :price="item.price" intSize="36" floatSize="36" labelSize="24" weight></priceFormat>
								</view>
								<view class="text-line fs-24 text--w111-999 Regular lh-32rpx" :style="[otPriceColor]"
									v-if="checkboxInfo.includes(3)">¥{{ item.ot_price.toString().split('.')[1] ?
										item.ot_price : item.ot_price + '.00' }}</view>
							</view>
							<view class="qiang flex-center fs-24 text--w111-fff" v-if="!showBtn" :style="[btnBgColor, getBtnOtherStyle(item)]">抢
								<text :style="{ backgroundImage: `url(${domain}/static/images/shandian.png)` }"></text>
							</view>
						</view>
					</view>
				</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
import countDown from '@/components/countDown';
import easyLoadimage from '@/components/easyLoadimage/easyLoadimage.vue';
import { getSeckillData } from '@/api/api.js';
import { getSeckillIndexTime } from '@/api/activity.js';
import { diyUtil } from '@/utils/diy';
import circleMixin from "./mixins/circle";
import { HTTP_REQUEST_URL } from '@/config/app';
export default {
	options: {
		styleIsolation: 'shared',
	},
	name: 'seckill',
	mixins: [circleMixin],
	components: {
		countDown,
		easyLoadimage
	},
	props: {
		dataConfig: {
			type: Object,
			default: () => { }
		},
		index: {
			type: Number,
			default: 0
		}
	},
	data() {
		return {
			datatime: '',
			spikeList: [],
			seckillTimeIndex: 0,
			seckillTime: [],
			domain: HTTP_REQUEST_URL
		};
	},
	computed: {
		wrapperStyle() {
			return {
				borderRadius: diyUtil.buildBorderRadius(this.dataConfig.fillet),
				overflow: 'hidden',
			};
		},
		titleStyle() {
			let titleText = this.dataConfig.titleText
			return {
				fontStyle: !titleText.tabVal ? 'normal' : titleText.tabList[titleText.tabVal].style,
				fontWeight: !titleText.tabVal ? 'bold' : 'normal',
				color: this.dataConfig.titleColor.color[0].item,
				fontSize: this.dataConfig.titleNumber.val * 2 + 'rpx'
			}
		},
		boxStyle() {
			return {
				boxShadow: diyUtil.buildShadowStyle(this.dataConfig.shadowConfig),
				padding: `${this.dataConfig.topConfig.val * 2}rpx ${this.dataConfig.prConfig.val * 2}rpx ${this.dataConfig.bottomConfig.val * 2}rpx`,
				marginTop: diyUtil.buildMarginTopOffset(this.dataConfig.mbConfig, this.dataConfig.offsetYConfig),
				zIndex: diyUtil.calcZIndex(this.index),
				background: this.dataConfig.bottomBgColor.color[0].item,
			}
		},
		tagBag() {
			const isCustomTone = this.dataConfig.toneConfig.tabVal === 1;
			const styles = {
				color: isCustomTone ? this.dataConfig.goodsBntTxtColor.color[0].item : '#fff',
			};

			if (isCustomTone) {
				styles.background = diyUtil.buildLinearColor(this.dataConfig.goodsBntColor);
			}

			return styles;
		},
		bargainPriceColor() {
			return this.dataConfig.toneConfig.tabVal ? this.dataConfig.seckillPriceColor2.color[0].item : '#fff'
		},
		boxContentStyle() {
			return {
				background: diyUtil.buildLinearColor(this.dataConfig.moduleColor),
			};
		},
		/*商品模板*/
		goodStyleConfig() {
			return this.dataConfig.goodStyleConfig.tabVal
		},
		styleConfig() {
			return this.dataConfig.styleConfig.tabVal
		},
		headerStyle() {
			let br = `${this.dataConfig.fillet.val * 2}rpx`,
				borderRadius = '',
				imgBgUrl = this.$util.BuildImgUrl(this.dataConfig.imgBgConfig.url);
			if (this.dataConfig.fillet.type) {
				borderRadius = `${this.dataConfig.fillet.valList[0].val * 2}rpx ${this.dataConfig.fillet.valList[1].val * 2}rpx 0 0`
			} else {
				borderRadius = `${br} ${br} 0 0`
			}
			return {
				backgroundImage: this.styleConfig ? 'url(' + imgBgUrl + ')' : `linear-gradient(90deg,${this.dataConfig.headerBgColor.color[0].item} 0%,${this.dataConfig.headerBgColor.color[1].item} 100%)`,
				borderRadius,

			}
		},
		/*标题是文本还是图片*/
		titleConfig() {
			return this.dataConfig.titleConfig.tabVal
		},
		/*标题文本*/
		titleTxtConfig() {
			return this.dataConfig.titleTxtConfig.value
		},
		/*标题图片*/
		titleImg() {
			return this.styleConfig ? this.titleUrl : this.titleColorUrl
		},
		titleColorUrl() {
			return this.dataConfig.imgColorConfig.url
		},
		titleUrl() {
			return this.dataConfig.imgConfig.url
		},
		/*标题提示文字*/
		tipsColor() {
			return {
				color: this.styleConfig ? this.dataConfig.tipsColor.color[0].item : this.dataConfig.tipsColor2.color[0].item
			}
		},
		/*头部按钮文本*/
		rightBntTxt() {
			return this.dataConfig.rightBntConfig.value
		},
		/*头部按钮样式*/
		headerBntColor() {
			return {
				color: this.styleConfig ? this.dataConfig.headerBntColor.color[0].item : this.dataConfig.headerBntColor2.color[0].item,
				fontSize: `${this.dataConfig.bntNumber.val * 2}rpx`
			}
		},
		/*商品图片圆角样式*/
		imgStyle() {
			let borderRadius = `${this.dataConfig.filletImg.val * 2}rpx`;
			if (this.dataConfig.filletImg.type) {
				borderRadius =
					`${this.dataConfig.filletImg.valList[0].val * 2}rpx ${this.dataConfig.filletImg.valList[1].val * 2}rpx ${this.dataConfig.filletImg.valList[3].val * 2}rpx ${this.dataConfig.filletImg.valList[2].val * 2}rpx`;
			}
			return borderRadius
		},
		/*商品名称样式*/
		productStyle() {
			return {
				color: this.dataConfig.goodsNameColor.color[0].item,
				fontWeight: this.dataConfig.goodsName.tabVal ? 'normal' : 'bold'
			}
		},
		/* 展示信息 */
		checkboxInfo() {
			return this.dataConfig.checkboxInfo.type
		},
		/* 价格颜色 */
		priceColor() {
			return this.dataConfig.toneConfig.tabVal ? this.dataConfig.progressTxtColor.color[0].item : 'var(--view-theme)'
		},
		/* 划线价颜色 */
		otPriceColor() {
			return {
				color: this.dataConfig.goodsPriceColor.color[0].item
			}
		},
		showBtn() {
			return this.dataConfig.seckillConfig.tabVal
		},
		/* 按钮颜色 */
		btnBgColor() {
			return {
				background: this.dataConfig.toneConfig.tabVal ? `linear-gradient(90deg,${this.dataConfig.goodsBntColor.color[1].item} 0%,${this.dataConfig.goodsBntColor.color[0].item} 100%)` : 'linear-gradient(90deg, var(--view-assist) 0%, var(--view-theme) 100%)',
				color: this.dataConfig.goodsBntTxtColor.color[0].item
			}
		},
		progressBgColor() {
			return this.dataConfig.toneConfig.tabVal ? `linear-gradient(90deg,${this.dataConfig.progressColor.color[0].item} 0%,${this.dataConfig.progressColor.color[1].item} 100%)` : 'linear-gradient(45deg, var(--view-assist) 0%, var(--view-theme) 100%)'
		},
		/*倒计时背景色*/
		numberBgColor() {
			const color = this.styleConfig ? this.dataConfig.numberBgColor : this.dataConfig.numberBgColor2;
			return {
				"--dot-color": this.dotColor,
				"--time-bg": diyUtil.buildLinearColor(color)
			};
		},
		numberColor() {
			return this.styleConfig ? this.dataConfig.numberColor.color[0].item : this.dataConfig.numberColor2.color[0].item
		},
		dotColor() {
			return this.styleConfig ? this.dataConfig.numberBgColor.color[0].item : this.dataConfig.numberBgColor2.color[0].item
		},
		/*商品数量*/
		numberConfig() {
			return this.dataConfig.numberConfig.val
		},
		goodStyle() {
			return {
				boxShadow: diyUtil.buildShadowStyle(this.dataConfig.goodsShadowConfig)
			};
		}
	},
	watch: {
		dataConfig: {
			handler() {
				this.getSeckillData();
				this.getSeckillIndexTime();
			},
			immediate: true
		}
	},
	inject: ["parentDiyId", "parentMerId"],
	filters: {
		btnText(skill_status) {
			return skill_status === 0 ? "未开始" : "去抢购";
		}
	},
	methods: {
		getBtnOtherStyle(good) {
			const style = {};
			if (good.skill_status === 0) style.opacity = 0.5;
			return style;
		},
		goPage() {
			const url = this.mergeUrl('/pages/activity/goods_seckill/index');
			uni.navigateTo({
				url
			})
		},
		goDetails(item) {
			if (item.skill_status === 0) return this.$util.Tips({
				title: "该商品尚未开始抢购"
			});
			uni.navigateTo({
				url: '/pages/activity/goods_seckill_details/index?id=' + item.product_id + '&type=1&time_id=' + this.seckillTime[this.seckillTimeIndex].seckill_time_id
			})
		},
		async getSeckillIndexTime() {
			try {
				const res = await getSeckillIndexTime();
				const { seckillTime, seckillTimeIndex } = res.data;
				this.seckillTime = seckillTime;
				this.seckillTimeIndex = seckillTimeIndex;
			} catch (error) {
				console.log(error);
				this.$util.Tips({
					title: error.message
				});
			}
		},
		refreshData() {
			this.getSeckillData();
		},
		getSeckillData() {
			let that = this;

			const params = {
				diy_id: that.parentDiyId,
				unique: that.dataConfig.timestamp,
				mer_id: that.parentMerId || "",
				limit: that.dataConfig.numberConfig.val
			}
			getSeckillData(this.mergeParams(params)).then(res => {
				that.datatime = res.data && res.data.stop;
				that.spikeList = res.data.list.map(item => {
					item.percent = item.stock === 0 ? 100 : (item.sales * 100 / (item.sales + item.stock)).toFixed(2);
					return item;
				});
			}).catch(e => { });
		},
	}
}
</script>

<style lang="scss" scoped>
.Regular {
	font-family: 'Regular';
}

::v-deep .styleAll {
	width: 36rpx;
	height: 36rpx;
	border-radius: 4rpx;
	font-size: 24rpx;
	line-height: 40rpx;
	display: inline-flex;
	align-items: center;
	justify-content: center;
	padding: 0;
}

.bg-cover {
	background-size: cover;

	::v-deep .styleAll {
		background-image: var(--time-bg);
	}

	::v-deep .timeTxt {
		color: var(--dot-color);
		margin: 0 6rpx;
		font-weight: bold;
	}
}

.item~.item {
	margin-top: 32rpx;
}

.progress {
	width: 240rpx;
	height: 24rpx;
	border-radius: 12rpx;
	background-color: rgba(253, 240, 237, 1);
	overflow: hidden;

	.active {
		height: 24rpx;
		border-radius: 12rpx;
		background: linear-gradient(45deg, #FF7931 0%, #E93323 100%);
	}

	.lightning {
		position: absolute;
		top: -2rpx;
		width: 28rpx;
		height: 28rpx;
	}
}

.price-box {
	width: 150rpx;
	height: 44rpx;
	background: linear-gradient(45deg, var(--view-assist) 0%, var(--view-theme) 100%);
	border-radius: 0px 8rpx 8rpx 0px;
	margin: 12rpx 0 0 10rpx;

	.shandian {
		position: absolute;
		width: 24rpx;
		height: 44rpx;
		top: 0;
		left: -10rpx;
	}
}

.qiang {
	width: 66rpx;
	height: 40rpx;
	background: linear-gradient(45deg, #FF7931 0%, #E93323 100%);
	border-radius: 0px 22rpx 22rpx 0px;
	position: relative;

	text {
		position: absolute;
		top: 0;
		left: -10rpx;
		width: 24rpx;
		height: 40rpx;
		background-size: cover;
	}
}

.border-box {
	box-sizing: border-box;
}

.seckill-wrapper {
	overflow: hidden;
}
</style>
